FundTech v1.01

1. Please use a Web Server to access the index.html (http://...)
2. Please do not use https. 
3. Please make sure you can access

http://fund.eastmoney.com/data/rankhandler.aspx?op=ph&dt=kf&ft=lof&rs=&gs=0&sc=zzf&st=desc&&qdii=&tabSubtype=,,,,,&pi=1&pn=10000&dx=1

and 

http://hq.sinajs.cn/list=test

