MazeEscape 1.03

MazeEscape is a first-person 3d Maze game. Version 1.01 was released in 2007. 

How to play

1. Launch the program and select options you need, and then click "Play".
2. Use mouse and "up", "down" keys to control. 
3. If you see a guard, you must avoid been caught by him. You can use the maze the get rid of him.
4. If you find a yellow light, it means you almost find the exit of the maze. You can escape and win the game.


Homepage

https://liuat.com/maze



